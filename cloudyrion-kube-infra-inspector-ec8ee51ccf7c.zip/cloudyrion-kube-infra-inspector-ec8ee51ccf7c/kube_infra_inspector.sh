#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
  cat <<'EOF'
Usage:
  ./kube_infra_inspector.sh -s <scan> -n <ns1,ns2,...> [-k <kubeconfig_path>]

Options:
  -s, --scan          Scan type to run.
  -n, --namespaces    Comma-separated namespaces (example: monitoring,logs,metrics)
  -k, --kubeconfig    Optional kubeconfig file path
  -h, --help          Show this help

Scan types:
  env                 Run scanners/pods/pod_env_scan.sh
  logs                Run scanners/logs/pod_log_secret_scan.sh
  hit-google          Run scanners/network/pod_egress_check.sh
  pods-metadata       Run scanners/metadata/pod_metadata_report.sh
  configmaps          Run scanners/config/configmap_secret_pattern_scan.sh
  configmaps2         Run scanners/config/configmap_secret_pattern_scan_fast.sh
  all                 Run all scans above sequentially

Examples:
  ./kube_infra_inspector.sh -s env -n monitoring,logs
  ./kube_infra_inspector.sh --scan hit-google --namespaces gr,ie
  ./kube_infra_inspector.sh -s all -n monitoring,logs,metrics
  ./kube_infra_inspector.sh -s logs -n monitoring -k ~/.kube/customer-prod.yaml
EOF
}

scan=""
namespaces=""
kubeconfig=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    -s|--scan)
      scan="${2:-}"
      shift 2
      ;;
    -n|--namespaces)
      namespaces="${2:-}"
      shift 2
      ;;
    -k|--kubeconfig)
      kubeconfig="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      usage
      exit 1
      ;;
  esac
done

if [[ -z "$scan" ]]; then
  echo "Error: --scan is required"
  usage
  exit 1
fi

if [[ -z "$namespaces" ]]; then
  echo "Error: --namespaces is required"
  usage
  exit 1
fi

# Exposed to child scripts. They parse comma-separated namespaces.
export SCAN_NAMESPACES="$namespaces"

# Optional kubeconfig override. If not set, kubectl uses default path resolution.
if [[ -n "$kubeconfig" ]]; then
  if [[ ! -f "$kubeconfig" ]]; then
    echo "Error: kubeconfig file not found: $kubeconfig"
    exit 1
  fi
  export KUBECONFIG="$kubeconfig"
fi

run_script() {
  local script_name="$1"
  local script_path="$SCRIPT_DIR/$script_name"

  if [[ ! -f "$script_path" ]]; then
    echo "Error: script not found: $script_name"
    exit 1
  fi

  echo "\n================================================"
  echo "Running $script_name"
  echo "Namespaces: $SCAN_NAMESPACES"
  echo "================================================"

  local args=(-n "$SCAN_NAMESPACES")
  if [[ -n "${KUBECONFIG:-}" ]]; then
    args+=(-k "$KUBECONFIG")
  fi

  bash "$script_path" "${args[@]}"
}

case "$scan" in
  env)
    run_script "scanners/pods/pod_env_scan.sh"
    ;;
  logs)
    run_script "scanners/logs/pod_log_secret_scan.sh"
    ;;
  hit-google)
    run_script "scanners/network/pod_egress_check.sh"
    ;;
  pods-metadata)
    run_script "scanners/metadata/pod_metadata_report.sh"
    ;;
  configmaps)
    run_script "scanners/config/configmap_secret_pattern_scan.sh"
    ;;
  configmaps2)
    run_script "scanners/config/configmap_secret_pattern_scan_fast.sh"
    ;;
  all)
    run_script "scanners/pods/pod_env_scan.sh"
    run_script "scanners/logs/pod_log_secret_scan.sh"
    run_script "scanners/network/pod_egress_check.sh"
    run_script "scanners/metadata/pod_metadata_report.sh"
    run_script "scanners/config/configmap_secret_pattern_scan.sh"
    run_script "scanners/config/configmap_secret_pattern_scan_fast.sh"
    ;;
  *)
    echo "Error: unknown scan type '$scan'"
    usage
    exit 1
    ;;
esac
