# Kubernetes Infrastructure Inspector

## Overview

Kubernetes Infrastructure Inspector is a lightweight Bash-based toolkit for checking Kubernetes namespaces for common security and visibility issues.

It runs targeted scans against selected namespaces using `kubectl`, with optional kubeconfig support.

## Purpose

The project helps quickly inspect:

* Pod environment variables
* Pod logs for secret-like values
* Pod metadata
* ConfigMaps for sensitive patterns
* Basic pod egress connectivity

## Entry Point

Main script:

```bash
./kube_infra_inspector.sh
```

## Usage

```bash
./kube_infra_inspector.sh -s <scan> -n <ns1,ns2,...> [-k <kubeconfig_path>]
```

Example:

```bash
./kube_infra_inspector.sh -s all -n monitoring,logs,metrics
```

With kubeconfig:

```bash
./kube_infra_inspector.sh -s logs -n ns1,ns2 -k ~/.kube/customer-prod.yaml
```

## Options

| Option               | Description                        |
| -------------------- | ---------------------------------- |
| `-s`, `--scan`       | Scan type to run                   |
| `-n`, `--namespaces` | Comma-separated list of namespaces |
| `-k`, `--kubeconfig` | Optional kubeconfig path           |
| `-h`, `--help`       | Show usage help                    |

## Scan Types

| Scan            | Script                                  | Purpose                                                                   |
| --------------- | --------------------------------------- | ------------------------------------------------------------------------- |
| `env`           | `pod_env_scan.sh`                       | Prints container environment variables                                    |
| `logs`          | `pod_log_secret_scan.sh`                | Searches pod logs for secret-like patterns                                |
| `hit-google`    | `pod_egress_check.sh`                   | Tests outbound connectivity to `google.com`                               |
| `pods-metadata` | `pod_metadata_report.sh`                | Reports pod labels, annotations, service account, node, and creation time |
| `configmaps`    | `configmap_secret_pattern_scan.sh`      | Scans ConfigMaps for sensitive keywords                                   |
| `configmaps2`   | `configmap_secret_pattern_scan_fast.sh` | Faster ConfigMap sensitive-pattern scan                                   |
| `all`           | Multiple scripts                        | Runs all scans sequentially                                               |

## What Each Scanner Does

### Pod Environment Scan

Checks pods in the selected namespaces and prints environment variables per container.

Useful for finding exposed values in pod specs.

### Pod Log Secret Scan

Reads pod logs across all containers and searches for sensitive keywords such as:

* `password`
* `secret`
* `token`
* `api_key`
* `authorization`
* `jwt`
* `private_key`
* `aws_access_key`
* `bearer`

### Pod Egress Check

Checks whether pods can reach:

```text
http://google.com
```

It attempts connectivity using available tools inside the pod:

* `curl`
* `wget`
* `nc`

### Pod Metadata Report

Exports basic pod metadata as JSON, including:

* Namespace
* Pod name
* Labels
* Annotations
* Service account
* Node name
* Creation timestamp

### ConfigMap Secret Pattern Scan

Scans ConfigMap YAML output for sensitive-looking keys or values using keyword matching.

This is useful for quickly identifying possible secrets stored incorrectly in ConfigMaps.

## Requirements

The machine running the scripts needs:

```bash
kubectl
jq
bash
```

For egress checks, target pods may need one of:

```bash
curl
wget
nc
```

## Notes

* Scripts rely on `SCAN_NAMESPACES`, which is set by the main launcher.
* If no kubeconfig is provided, `kubectl` uses its default resolution.
* Findings are pattern-based and should be reviewed manually.
* A match does not always mean a real secret is exposed.
* No cluster changes are made; scans are read-only except for `kubectl exec` used during egress testing.

## Recommended Run

For a full namespace review:

```bash
./kube_infra_inspector.sh -s all -n monitoring,logs,metrics
```

For customer or isolated cluster checks:

```bash
./kube_infra_inspector.sh -s all -n <namespace1>,<namespace2> -k <kubeconfig_path>
```

## Output Review

After running scans, review output for:

* Plaintext secrets in environment variables
* Secret-like values in logs
* Sensitive keys in ConfigMaps
* Unexpected pod egress access
* Suspicious annotations or service accounts

## Next Improvements

Keep this simple. Suggested next steps:

* Save scan output to timestamped files
* Add a summary section at the end of each scan
* Add exit codes for CI usage
* Add optional JSON output
