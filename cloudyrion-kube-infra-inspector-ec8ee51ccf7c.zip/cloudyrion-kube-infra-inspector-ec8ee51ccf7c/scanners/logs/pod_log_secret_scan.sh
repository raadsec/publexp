#!/bin/bash

set -euo pipefail

namespaces_arg="${SCAN_NAMESPACES:-}"
kubeconfig_arg="${KUBECONFIG:-}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -n|--namespaces)
      namespaces_arg="${2:-}"
      shift 2
      ;;
    -k|--kubeconfig)
      kubeconfig_arg="${2:-}"
      shift 2
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

if [[ -n "$kubeconfig_arg" ]]; then
  KUBECTL=(kubectl --kubeconfig "$kubeconfig_arg")
else
  KUBECTL=(kubectl)
fi

keywords="(?i)password|passwd|pwd|secret|token|api[_-]?key|apikey|auth|credential|jwt|session|private[_-]?key|access[_-]?key|secret[_-]?key|ssh[_-]?key|aws[_-]?(access[_-]?key|secret[_-]?key|session[_-]?token)|s3[_-]?key|rsa[_-]?key|oauth|bearer|mysql[_-]?pwd|db[_-]?password|db[_-]?user|encryption[_-]?key|cookie|set-cookie|authorization|auth[_-]?token|x-api-key|cleartext|plaintext"
DEFAULT_NAMESPACES=("monitoring" "logs" "metrics")
if [[ -n "$namespaces_arg" ]]; then
  cleaned="${namespaces_arg// /}"
  IFS=',' read -r -a namespaces <<< "$cleaned"
else
  namespaces=("${DEFAULT_NAMESPACES[@]}")
fi

for ns in "${namespaces[@]}"; do
  echo -e "\nNamespace: $ns"

  "${KUBECTL[@]}" get pods -n "$ns" --no-headers -o custom-columns=":metadata.name" | while read -r pod; do
    echo -e "\nChecking pod: $pod"
    "${KUBECTL[@]}" logs "$pod" -n "$ns" --all-containers=true 2>/dev/null | grep -Ei --color "$keywords" || echo "No matches found."
  done
done
