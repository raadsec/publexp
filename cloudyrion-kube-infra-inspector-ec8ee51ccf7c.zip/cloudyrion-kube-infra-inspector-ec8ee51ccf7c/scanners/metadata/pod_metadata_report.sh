#!/bin/bash

set -euo pipefail

namespaces_arg="${SCAN_NAMESPACES:-}"
kubeconfig_arg="${KUBECONFIG:-}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        -n|--namespaces)
            namespaces_arg="${2:-}"
            shift 2
            ;;
        -k|--kubeconfig)
            kubeconfig_arg="${2:-}"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -n "$kubeconfig_arg" ]]; then
    KUBECTL=(kubectl --kubeconfig "$kubeconfig_arg")
else
    KUBECTL=(kubectl)
fi

DEFAULT_NAMESPACES=("monitoring" "logs" "metrics")
if [[ -n "$namespaces_arg" ]]; then
    cleaned="${namespaces_arg// /}"
    IFS=',' read -r -a namespaces <<< "$cleaned"
else
    namespaces=("${DEFAULT_NAMESPACES[@]}")
fi

ns_regex="^($(IFS='|'; echo "${namespaces[*]}"))$"

"${KUBECTL[@]}" get pods -A -o json | jq --arg ns_regex "$ns_regex" '.items[] | select(.metadata.namespace | test($ns_regex)) | {
    namespace: .metadata.namespace,
    pod_name: .metadata.name,
    labels: .metadata.labels,
    annotations: .metadata.annotations,
    serviceAccount: .spec.serviceAccountName,
    nodeName: .spec.nodeName,
    creationTimestamp: .metadata.creationTimestamp
}'
