#!/usr/bin/env bash

set -euo pipefail

namespaces_arg="${SCAN_NAMESPACES:-}"
kubeconfig_arg="${KUBECONFIG:-}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        -n|--namespaces)
            namespaces_arg="${2:-}"
            shift 2
            ;;
        -k|--kubeconfig)
            kubeconfig_arg="${2:-}"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [[ -n "$kubeconfig_arg" ]]; then
    KUBECTL=(kubectl --kubeconfig "$kubeconfig_arg")
else
    KUBECTL=(kubectl)
fi

# Namespaces to scan (array)
DEFAULT_NAMESPACES=("gr" "ie")
if [[ -n "$namespaces_arg" ]]; then
    cleaned="${namespaces_arg// /}"
    IFS=',' read -r -a NAMESPACES <<< "$cleaned"
else
    NAMESPACES=("${DEFAULT_NAMESPACES[@]}")
fi

# Tools to test in each pod
TOOLS=("curl" "wget" "nc")

TARGET_DOMAIN="google.com"
TARGET_URL="http://google.com"
TARGET_PORT=80
TIMEOUT=4   # seconds

echo "Checking connectivity to $TARGET_DOMAIN in namespaces: ${NAMESPACES[*]}"
echo "---------------------------------------------------------------"

for ns in "${NAMESPACES[@]}"; do
    echo -e "\n🔹 Namespace: $ns"

    # Fetch pods one per line
    pods=$("${KUBECTL[@]}" get pods -n "$ns" -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}')

    echo "Pods:"
    echo "$pods"

    if [[ -z "$pods" ]]; then
        echo "  No pods found."
        continue
    fi

    # Convert newline list to array
    POD_ARRAY=()
    while IFS= read -r pod; do
        [[ -n "$pod" ]] && POD_ARRAY+=("$pod")
    done <<< "$pods"

    for pod in "${POD_ARRAY[@]}"; do
        echo -e "\n  ➤ Pod: $pod"

        for tool in "${TOOLS[@]}"; do
            echo -e "\n    Trying $tool (timeout ${TIMEOUT}s)..."

            # Check if tool exists in container
            "${KUBECTL[@]}" exec -n "$ns" "$pod" -- sh -c "command -v $tool" >/dev/null 2>&1
            if [[ $? -ne 0 ]]; then
                echo "    ✖ $tool not installed"
                continue
            fi

            echo "    Command output:"
            echo "    --------------------------"

            case $tool in
                curl)
                    "${KUBECTL[@]}" exec -n "$ns" "$pod" -- \
                        sh -c "curl --max-time $TIMEOUT $TARGET_URL"
                    ;;
                wget)
                    "${KUBECTL[@]}" exec -n "$ns" "$pod" -- \
                        sh -c "wget -T $TIMEOUT -q -O - $TARGET_URL"
                    ;;
                nc)
                    # -w sets timeout
                    "${KUBECTL[@]}" exec -n "$ns" "$pod" -- \
                        sh -c "nc -w $TIMEOUT $TARGET_DOMAIN $TARGET_PORT"
                    ;;
            esac

            echo -e "\n    --------------------------"
        done
    done
done

echo -e "\n✔️ Connectivity check completed."
