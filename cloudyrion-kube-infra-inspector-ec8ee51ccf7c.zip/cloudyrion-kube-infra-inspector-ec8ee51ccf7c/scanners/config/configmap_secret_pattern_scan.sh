#!/bin/bash

set -euo pipefail

namespaces_arg="${SCAN_NAMESPACES:-}"
kubeconfig_arg="${KUBECONFIG:-}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -n|--namespaces)
      namespaces_arg="${2:-}"
      shift 2
      ;;
    -k|--kubeconfig)
      kubeconfig_arg="${2:-}"
      shift 2
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

if [[ -n "$kubeconfig_arg" ]]; then
  KUBECTL=(kubectl --kubeconfig "$kubeconfig_arg")
else
  KUBECTL=(kubectl)
fi

# Same keyword regex you provided
keywords="(?i)password|passwd|pwd|secret|token|api[_-]?key|apikey|auth|credential|jwt|session|private[_-]?key|access[_-]?key|secret[_-]?key|ssh[_-]?key|aws[_-]?(access[_-]?key|secret[_-]?key|session[_-]?token)|s3[_-]?key|rsa[_-]?key|oauth|bearer|mysql[_-]?pwd|db[_-]?password|db[_-]?user|encryption[_-]?key|cookie|set-cookie|authorization|auth[_-]?token|x-api-key|cleartext|plaintext"

# Define namespaces to check
DEFAULT_NAMESPACES=("monitoring" "logs" "metrics")
if [[ -n "$namespaces_arg" ]]; then
  cleaned="${namespaces_arg// /}"
  IFS=',' read -r -a namespaces <<< "$cleaned"
else
  namespaces=("${DEFAULT_NAMESPACES[@]}")
fi

for ns in "${namespaces[@]}"; do
  echo -e "\n============================"
  echo -e "Namespace: $ns"
  echo -e "============================"

  # List configmaps in this namespace
  configmaps=$("${KUBECTL[@]}" get configmaps -n "$ns" --no-headers -o custom-columns=":metadata.name")

  if [[ -z "$configmaps" ]]; then
    echo "No ConfigMaps found."
    continue
  fi

  # Loop through ConfigMaps
  echo "$configmaps" | while read -r cm; do
    echo -e "\nChecking ConfigMap: $cm"

    # Get configmap contents and grep for sensitive patterns
    "${KUBECTL[@]}" get configmap "$cm" -n "$ns" -o yaml 2>/dev/null | \
      grep -Ei --color "$keywords" && found=1

    if [[ -z "$found" ]]; then
      echo "No matches found."
    fi

    unset found
  done
done
